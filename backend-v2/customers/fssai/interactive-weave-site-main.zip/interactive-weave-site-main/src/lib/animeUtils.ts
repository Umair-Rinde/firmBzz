
import anime from "animejs";

export type AnimeInstance = anime.AnimeInstance;

// Helper to create staggered text animation
export const createTextAnimation = (selector: string, delay: number = 0) => {
  const textWrapper = document.querySelector(selector);
  if (!textWrapper) return;
  
  textWrapper.innerHTML = textWrapper.textContent!.replace(
    /\S+/g,
    "<span class='inline-block overflow-hidden'><span class='inline-block opacity-0 translate-y-full'>$&</span></span>"
  );

  return anime
    .timeline({
      autoplay: false,
    })
    .add({
      targets: `${selector} span span`,
      translateY: ["100%", 0],
      opacity: [0, 1],
      easing: "easeOutExpo",
      duration: 800,
      delay: (el, i) => delay + 40 * i,
    });
};

// Create interactive background animation
export const createParticlesAnimation = (containerId: string, particleCount: number = 50) => {
  const container = document.getElementById(containerId);
  if (!container) return;

  // Clear existing particles
  container.innerHTML = "";

  // Create particles
  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement("div");
    particle.classList.add("particle");
    particle.style.position = "absolute";
    particle.style.width = `${Math.random() * 4 + 2}px`;
    particle.style.height = particle.style.width;
    particle.style.backgroundColor = `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 0.3 + 0.2})`;
    particle.style.borderRadius = "50%";
    particle.style.top = `${Math.random() * 100}%`;
    particle.style.left = `${Math.random() * 100}%`;
    
    container.appendChild(particle);
  }

  // Animate particles
  return anime({
    targets: ".particle",
    translateX: () => anime.random(-100, 100),
    translateY: () => anime.random(-100, 100),
    scale: () => anime.random(0.5, 2),
    opacity: () => anime.random(0.2, 0.8),
    duration: () => anime.random(3000, 5000),
    easing: "easeInOutQuad",
    loop: true,
    direction: "alternate",
    delay: () => anime.random(0, 1000),
  });
};

// Create mouse follow animation
export const createMouseFollowAnimation = () => {
  const cursorDot = document.createElement("div");
  cursorDot.classList.add("cursor-dot");
  
  const cursorOutline = document.createElement("div");
  cursorOutline.classList.add("cursor-outline");
  
  document.body.appendChild(cursorDot);
  document.body.appendChild(cursorOutline);
  
  window.addEventListener("mousemove", (e) => {
    anime({
      targets: cursorDot,
      translateX: e.clientX,
      translateY: e.clientY,
      easing: "easeOutExpo",
      duration: 100,
    });
    
    anime({
      targets: cursorOutline,
      translateX: e.clientX - 20,
      translateY: e.clientY - 20,
      easing: "easeOutExpo",
      duration: 300,
    });
  });

  document.querySelectorAll("a, button, [data-cursor='pointer']").forEach((el) => {
    el.addEventListener("mouseenter", () => {
      cursorOutline.style.width = "60px";
      cursorOutline.style.height = "60px";
      cursorOutline.style.opacity = "0.3";
    });
    
    el.addEventListener("mouseleave", () => {
      cursorOutline.style.width = "40px";
      cursorOutline.style.height = "40px";
      cursorOutline.style.opacity = "0.5";
    });
  });
};

// Create interactive shape animation
export const createInteractiveShape = (
  canvasId: string,
  color: string = "rgba(124, 77, 255, 0.6)"
) => {
  const canvas = document.getElementById(canvasId) as HTMLCanvasElement;
  if (!canvas) return;
  
  const ctx = canvas.getContext("2d")!;
  canvas.width = canvas.offsetWidth;
  canvas.height = canvas.offsetHeight;
  
  let mousePosition = { x: canvas.width / 2, y: canvas.height / 2 };
  let lastMousePosition = { ...mousePosition };
  
  canvas.addEventListener("mousemove", (e) => {
    const rect = canvas.getBoundingClientRect();
    mousePosition = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  });
  
  window.addEventListener("resize", () => {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  });
  
  const points: { x: number; y: number; vx: number; vy: number }[] = [];
  for (let i = 0; i < 50; i++) {
    points.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: Math.random() * 2 - 1,
      vy: Math.random() * 2 - 1,
    });
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Update points position
    for (const point of points) {
      // Apply some mouse influence
      const dx = mousePosition.x - point.x;
      const dy = mousePosition.y - point.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < 150) {
        const force = (150 - distance) / 500;
        point.vx += dx * force;
        point.vy += dy * force;
      }
      
      point.x += point.vx;
      point.y += point.vy;
      
      // Add some friction
      point.vx *= 0.98;
      point.vy *= 0.98;
      
      // Boundary check
      if (point.x < 0) {
        point.x = 0;
        point.vx *= -1;
      }
      if (point.x > canvas.width) {
        point.x = canvas.width;
        point.vx *= -1;
      }
      if (point.y < 0) {
        point.y = 0;
        point.vy *= -1;
      }
      if (point.y > canvas.height) {
        point.y = canvas.height;
        point.vy *= -1;
      }
    }
    
    // Draw lines between close points
    ctx.strokeStyle = color;
    ctx.beginPath();
    for (let i = 0; i < points.length; i++) {
      for (let j = i + 1; j < points.length; j++) {
        const dx = points[i].x - points[j].x;
        const dy = points[i].y - points[j].y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 100) {
          ctx.globalAlpha = 1 - distance / 100;
          ctx.beginPath();
          ctx.moveTo(points[i].x, points[i].y);
          ctx.lineTo(points[j].x, points[j].y);
          ctx.stroke();
        }
      }
    }
    
    // Draw points
    ctx.globalAlpha = 0.5;
    for (const point of points) {
      ctx.beginPath();
      ctx.arc(point.x, point.y, 2, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
    }
    
    lastMousePosition = { ...mousePosition };
    requestAnimationFrame(animate);
  }
  
  animate();
};

// Create parallax effect for hero section
export const createParallaxEffect = (containerId: string) => {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  const elements = container.querySelectorAll("[data-parallax]");
  
  window.addEventListener("mousemove", (e) => {
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    
    const moveX = (clientX - innerWidth / 2) / innerWidth;
    const moveY = (clientY - innerHeight / 2) / innerHeight;
    
    elements.forEach((element) => {
      const speed = parseFloat(element.getAttribute("data-parallax") || "5");
      
      element.animate(
        {
          transform: `translate(${moveX * speed}px, ${moveY * speed}px)`,
        },
        { duration: 1000, fill: "forwards", easing: "ease-out" }
      );
    });
  });
};

// Create scroll animation
export const createScrollAnimation = (selectors: { [key: string]: string }) => {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const element = entry.target;
          const animationClass = element.getAttribute("data-animation") || "fade-in";
          element.classList.add(`animate-${animationClass}`);
        }
      });
    },
    { threshold: 0.15 }
  );

  Object.entries(selectors).forEach(([selector, animationClass]) => {
    document.querySelectorAll(selector).forEach((element) => {
      element.setAttribute("data-animation", animationClass);
      element.classList.add("opacity-0");
      observer.observe(element);
    });
  });
};

// Hook to add click effect
export const addClickEffects = () => {
  document.addEventListener("click", (e) => {
    const { clientX, clientY } = e;
    
    const ripple = document.createElement("div");
    ripple.classList.add("ripple");
    ripple.style.position = "fixed";
    ripple.style.width = "10px";
    ripple.style.height = "10px";
    ripple.style.borderRadius = "50%";
    ripple.style.backgroundColor = "rgba(255, 255, 255, 0.5)";
    ripple.style.top = `${clientY - 5}px`;
    ripple.style.left = `${clientX - 5}px`;
    ripple.style.pointerEvents = "none";
    ripple.style.zIndex = "9999";
    
    document.body.appendChild(ripple);
    
    anime({
      targets: ripple,
      scale: [0, 10],
      opacity: [1, 0],
      easing: "easeOutExpo",
      duration: 1000,
      complete: () => {
        document.body.removeChild(ripple);
      },
    });
  });
};

// Initialize all animations
export const initAnimations = () => {
  // Add mouse follower
  createMouseFollowAnimation();
  
  // Add click effects
  addClickEffects();
  
  // Add scroll animations
  createScrollAnimation({
    ".fade-in-element": "fade-in",
    ".slide-in-left-element": "slide-in-left",
    ".slide-in-right-element": "slide-in-right",
    ".scale-in-element": "scale-in",
  });
  
  // Add parallax effect to hero section
  createParallaxEffect("hero-section");
  
  // Initialize playground
  const playgroundCanvas = document.getElementById("playground-canvas") as HTMLCanvasElement;
  if (playgroundCanvas) {
    createInteractiveShape("playground-canvas");
  }
  
  // Animate logo on load
  anime({
    targets: "#logo",
    opacity: [0, 1],
    translateY: ["-20px", "0px"],
    easing: "easeOutExpo",
    duration: 800,
  });
  
  // Animate navigation items
  anime({
    targets: "nav a",
    opacity: [0, 1],
    translateY: ["-20px", "0px"],
    easing: "easeOutExpo",
    duration: 800,
    delay: anime.stagger(100, { start: 300 }),
  });
  
  // Animate hero section elements
  anime({
    targets: "#hero-title span",
    opacity: [0, 1],
    translateY: ["50px", "0px"],
    easing: "easeOutExpo",
    duration: 800,
    delay: anime.stagger(100, { start: 800 }),
  });
  
  // Animate social icons
  anime({
    targets: ".social-icon",
    opacity: [0, 1],
    scale: [0.5, 1],
    easing: "easeOutExpo",
    duration: 800,
    delay: anime.stagger(100, { start: 1200 }),
  });
  
  // Setup tech stack icons hover animation
  document.querySelectorAll(".tech-icon").forEach((el) => {
    el.addEventListener("mouseenter", (e) => {
      anime({
        targets: e.currentTarget,
        scale: 1.15,
        rotate: "10deg",
        duration: 300,
        easing: "easeOutExpo",
      });
    });
    
    el.addEventListener("mouseleave", (e) => {
      anime({
        targets: e.currentTarget,
        scale: 1,
        rotate: "0deg",
        duration: 300,
        easing: "easeOutExpo",
      });
    });
  });
  
  // Setup form input animations
  document.querySelectorAll(".form-input").forEach((input) => {
    const inputEl = input as HTMLInputElement;
    const label = input.parentElement?.querySelector("label");
    
    inputEl.addEventListener("focus", () => {
      anime({
        targets: label,
        translateY: ["-5px", "-25px"],
        scale: [1, 0.85],
        color: "#7C4DFF",
        easing: "easeOutExpo",
        duration: 300,
      });
    });
    
    inputEl.addEventListener("blur", () => {
      if (!inputEl.value) {
        anime({
          targets: label,
          translateY: ["-25px", "-5px"],
          scale: [0.85, 1],
          color: "#FFFFFF",
          easing: "easeOutExpo",
          duration: 300,
        });
      }
    });
  });
};

// Delay to allow DOM to load
export const initAnimationsWithDelay = () => {
  if (document.readyState === "complete") {
    initAnimations();
  } else {
    window.addEventListener("load", initAnimations);
  }
};
