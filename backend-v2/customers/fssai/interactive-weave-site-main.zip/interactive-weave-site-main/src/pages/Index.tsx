
import { useEffect } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import SkillsSection from "@/components/SkillsSection";
import ProjectsSection from "@/components/ProjectsSection";
import PlaygroundSection from "@/components/PlaygroundSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import { initAnimationsWithDelay } from "@/lib/animeUtils";

const Index = () => {
  useEffect(() => {
    // Initialize all animations
    initAnimationsWithDelay();
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <HeroSection />
        <AboutSection />
        <SkillsSection />
        <ProjectsSection />
        <PlaygroundSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
