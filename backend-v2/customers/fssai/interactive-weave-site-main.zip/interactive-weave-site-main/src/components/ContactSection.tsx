
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import anime from "animejs";

const ContactSection = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const nameRef = useRef<HTMLDivElement>(null);
  const emailRef = useRef<HTMLDivElement>(null);
  const messageRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  
  const { toast } = useToast();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      
      toast({
        title: "Message sent!",
        description: "Thank you for your message. I'll get back to you soon.",
      });
      
      // Animate the success message
      anime({
        targets: "#success-message",
        translateY: [20, 0],
        opacity: [0, 1],
        easing: "easeOutExpo",
        duration: 800,
      });
      
      // Reset form after animation
      setTimeout(() => {
        setName("");
        setEmail("");
        setMessage("");
        setSubmitted(false);
      }, 3000);
    }, 1500);
  };
  
  useEffect(() => {
    // Add focus and blur animations to form inputs
    const inputs = document.querySelectorAll(".form-control");
    
    inputs.forEach((input) => {
      const inputEl = input as HTMLInputElement;
      const label = inputEl.previousElementSibling as HTMLLabelElement;
      
      inputEl.addEventListener("focus", () => {
        anime({
          targets: label,
          color: "#7C4DFF",
          translateY: -10,
          scale: 0.85,
          duration: 300,
          easing: "easeOutExpo",
        });
        
        anime({
          targets: inputEl.nextElementSibling,
          scaleX: 1,
          duration: 300,
          easing: "easeOutExpo",
        });
      });
      
      inputEl.addEventListener("blur", () => {
        if (!inputEl.value) {
          anime({
            targets: label,
            color: "#888",
            translateY: 0,
            scale: 1,
            duration: 300,
            easing: "easeOutExpo",
          });
        } else {
          anime({
            targets: label,
            color: "#888",
            duration: 300,
            easing: "easeOutExpo",
          });
        }
        
        anime({
          targets: inputEl.nextElementSibling,
          scaleX: 0,
          duration: 300,
          easing: "easeOutExpo",
        });
      });
    });
    
    // Animate submit button on hover
    const submitBtn = document.querySelector("#submit-btn");
    if (submitBtn) {
      submitBtn.addEventListener("mouseenter", () => {
        anime({
          targets: submitBtn,
          scale: 1.05,
          duration: 300,
          easing: "easeOutExpo",
        });
      });
      
      submitBtn.addEventListener("mouseleave", () => {
        anime({
          targets: submitBtn,
          scale: 1,
          duration: 300,
          easing: "easeOutExpo",
        });
      });
    }
  }, []);

  return (
    <section id="contact" className="py-20 bg-muted/20">
      <div className="section">
        <h2 className="section-title slide-in-left-element">Get In Touch</h2>
        <p className="section-subtitle slide-in-left-element" style={{ animationDelay: "100ms" }}>
          Have a project in mind or want to collaborate? Let's talk!
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
          <Card className="p-8 bg-card scale-in-element" style={{ animationDelay: "200ms" }}>
            <form ref={formRef} onSubmit={handleSubmit}>
              <div className="mb-6 relative" ref={nameRef}>
                <label 
                  htmlFor="name" 
                  className="absolute left-3 top-3 text-muted-foreground pointer-events-none transition-all duration-300"
                  style={{ transformOrigin: "left" }}
                >
                  Your Name
                </label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="form-control bg-muted/30 border-muted pt-6 px-3"
                  disabled={submitting || submitted}
                  required
                />
                <span className="absolute bottom-0 left-0 h-0.5 w-full bg-purple scale-x-0 origin-center"></span>
              </div>
              
              <div className="mb-6 relative" ref={emailRef}>
                <label 
                  htmlFor="email" 
                  className="absolute left-3 top-3 text-muted-foreground pointer-events-none transition-all duration-300"
                  style={{ transformOrigin: "left" }}
                >
                  Your Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="form-control bg-muted/30 border-muted pt-6 px-3"
                  disabled={submitting || submitted}
                  required
                />
                <span className="absolute bottom-0 left-0 h-0.5 w-full bg-purple scale-x-0 origin-center"></span>
              </div>
              
              <div className="mb-6 relative" ref={messageRef}>
                <label 
                  htmlFor="message" 
                  className="absolute left-3 top-3 text-muted-foreground pointer-events-none transition-all duration-300"
                  style={{ transformOrigin: "left" }}
                >
                  Your Message
                </label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="form-control bg-muted/30 border-muted min-h-[150px] pt-6 px-3 resize-none"
                  disabled={submitting || submitted}
                  required
                />
                <span className="absolute bottom-0 left-0 h-0.5 w-full bg-purple scale-x-0 origin-center"></span>
              </div>
              
              <Button 
                id="submit-btn"
                type="submit"
                className="btn btn-primary w-full"
                disabled={submitting || submitted}
              >
                {submitting ? "Sending..." : "Send Message"}
              </Button>
              
              {submitted && (
                <div id="success-message" className="mt-4 text-center text-green-500 opacity-0">
                  Message sent successfully!
                </div>
              )}
            </form>
          </Card>
          
          <div className="space-y-6 scale-in-element" style={{ animationDelay: "300ms" }}>
            <div>
              <h3 className="text-2xl font-bold mb-4 text-gradient">Let's Connect</h3>
              <p className="text-muted-foreground mb-6">
                I'm always interested in new projects and collaborations. Whether you have a specific project in mind or just want to chat about possibilities, I'm here to help bring your vision to life.
              </p>
            </div>
            
            <div className="bg-card p-6 rounded-lg">
              <h4 className="font-bold mb-2">Contact Information</h4>
              <ul className="space-y-3">
                <li className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                    </svg>
                  </div>
                  <span>(123) 456-7890</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                      <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                  </div>
                  <span>contact@example.com</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                      <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                  </div>
                  <span>San Francisco, CA</span>
                </li>
              </ul>
            </div>
            
            <div className="text-center md:text-left">
              <h4 className="font-bold mb-2">Follow Me</h4>
              <div className="flex gap-4 mt-2 justify-center md:justify-start">
                <a 
                  href="#" 
                  className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-purple transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>
                  </svg>
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-blue transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect x="2" y="9" width="4" height="12"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-pink transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
