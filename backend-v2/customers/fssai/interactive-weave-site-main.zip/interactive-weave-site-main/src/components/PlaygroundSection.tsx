
import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import anime from "animejs";

const PlaygroundSection = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const shapes: { x: number; y: number; radius: number; color: string }[] = [];
  
  const spawnShape = (x: number, y: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const colors = [
      "rgba(124, 77, 255, 0.7)", // purple
      "rgba(58, 134, 255, 0.7)", // blue
      "rgba(255, 0, 110, 0.7)", // pink
    ];
    
    const shape = document.createElement("div");
    shape.classList.add("shape");
    shape.style.position = "absolute";
    shape.style.top = `${y - 25}px`;
    shape.style.left = `${x - 25}px`;
    shape.style.width = "50px";
    shape.style.height = "50px";
    shape.style.borderRadius = Math.random() > 0.5 ? "50%" : "4px";
    shape.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    shape.style.pointerEvents = "none";
    
    document.getElementById("playground-container")?.appendChild(shape);
    
    anime({
      targets: shape,
      translateX: () => anime.random(-200, 200),
      translateY: () => anime.random(-200, 200),
      scale: [
        { value: 0.1, duration: 0, delay: 0 },
        { value: 1, duration: 500, delay: 0 },
        { value: 0, duration: 1000, delay: 1000 },
      ],
      rotate: () => anime.random(-180, 180),
      opacity: [
        { value: 0, duration: 0, delay: 0 },
        { value: 0.8, duration: 500, delay: 0 },
        { value: 0, duration: 1000, delay: 1000 },
      ],
      easing: "easeOutElastic(1, .6)",
      complete: () => {
        shape.remove();
      },
    });
  };
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const container = document.getElementById("playground-container");
    if (!container) return;
    
    container.addEventListener("click", (e) => {
      const rect = container.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      // Spawn multiple shapes for a more dramatic effect
      for (let i = 0; i < 5; i++) {
        setTimeout(() => {
          spawnShape(x, y);
        }, i * 50);
      }
    });
    
    // Add intro animation to the text
    anime({
      targets: "#playground-title path",
      strokeDashoffset: [anime.setDashoffset, 0],
      easing: "easeInOutSine",
      duration: 1500,
      delay: function(el, i) { return i * 250 },
      direction: "alternate",
      loop: true
    });
  }, []);
  
  return (
    <section id="playground" className="py-20">
      <div className="section">
        <h2 className="section-title fade-in-element">Interactive Playground</h2>
        <p className="section-subtitle fade-in-element" style={{ animationDelay: "100ms" }}>
          Click anywhere in the canvas below to create animated shapes.
        </p>
        
        <Card className="p-8 mt-8 bg-card/50 backdrop-blur-sm relative overflow-hidden">
          <div className="mb-8 text-center">
            <svg id="playground-title" viewBox="0 0 400 50" width="100%" height="50">
              <path 
                fill="none" 
                stroke="#7C4DFF" 
                strokeWidth="2"
                d="M10,25 Q50,10 100,25 T200,25 T300,25 T390,25" 
              />
              <text 
                x="200" 
                y="30" 
                textAnchor="middle" 
                fill="#fff"
                fontFamily="Poppins, sans-serif"
                fontSize="18"
              >
                Click anywhere in this area
              </text>
            </svg>
          </div>
          
          <div 
            id="playground-container"
            className="relative h-[400px] bg-muted/30 rounded-lg cursor-pointer overflow-hidden"
          >
            <canvas 
              ref={canvasRef} 
              id="playground-canvas"
              width="800"
              height="400"
              className="w-full h-full"
            ></canvas>
            
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20 select-none">
              <p className="text-2xl font-bold">Click me!</p>
            </div>
          </div>
          
          <div className="mt-8 text-center">
            <p className="text-lg mb-4">
              This interactive area demonstrates anime.js's dynamic shape creation and animation.
            </p>
            <p className="text-muted-foreground">
              Each click spawns custom animated shapes with random properties, showcasing the library's flexibility.
            </p>
          </div>
        </Card>
        
        <div className="mt-12 text-center">
          <Button className="btn btn-primary">Learn More About anime.js</Button>
        </div>
      </div>
    </section>
  );
};

export default PlaygroundSection;
