
import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { createTextAnimation } from "@/lib/animeUtils";
import anime from "animejs";

interface FactCardProps {
  title: string;
  content: string;
  index: number;
}

const FactCard = ({ title, content, index }: FactCardProps) => {
  const cardRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;
    
    card.addEventListener("click", () => {
      anime({
        targets: card,
        rotateY: "+=180",
        easing: "easeInOutQuad",
        duration: 800,
      });
    });
  }, []);
  
  return (
    <div 
      ref={cardRef}
      className="bg-card p-6 rounded-lg shadow-lg card-hover cursor-pointer relative min-h-[200px] perspective-1000"
      style={{ 
        transform: "translateZ(0)",
        transformStyle: "preserve-3d", 
        animationDelay: `${index * 100}ms` 
      }}
      data-cursor="pointer"
    >
      <div className="backface-hidden">
        <h3 className="text-xl font-bold mb-2 text-purple-light">{title}</h3>
        <p className="text-muted-foreground">{content}</p>
        <div className="mt-4 text-sm text-purple">Click to flip</div>
      </div>
      <div 
        className="absolute inset-0 p-6 bg-purple/90 rounded-lg flex items-center justify-center backface-hidden"
        style={{ transform: "rotateY(180deg)" }}
      >
        <p className="text-white text-center">More details about {title} coming soon!</p>
      </div>
    </div>
  );
};

const AboutSection = () => {
  const textRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const textAnimation = createTextAnimation("#about-text", 300);
            if (textAnimation) textAnimation.play();
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    
    if (textRef.current) {
      observer.observe(textRef.current);
    }
    
    return () => {
      if (textRef.current) {
        observer.unobserve(textRef.current);
      }
    };
  }, []);

  const facts = [
    {
      title: "Education",
      content: "Master's degree in Computer Science with focus on Interactive Media and Game Development.",
    },
    {
      title: "Experience",
      content: "5+ years of professional experience in front-end development and UI/UX design.",
    },
    {
      title: "Approach",
      content: "I blend technical excellence with creative design to build memorable digital experiences.",
    },
    {
      title: "Passion",
      content: "Dedicated to creating performant animations that tell stories and engage users.",
    },
  ];

  return (
    <section id="about" className="py-20 bg-muted/20">
      <div className="section">
        <h2 className="section-title slide-in-left-element">About Me</h2>
        <p className="section-subtitle slide-in-left-element" style={{ animationDelay: "100ms" }}>
          Get to know me and my journey in web development.
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div 
              id="about-text"
              ref={textRef} 
              className="text-lg leading-relaxed opacity-0"
            >
              I'm a passionate front-end developer focused on creating immersive web experiences. With a strong foundation in JavaScript and modern frameworks, I specialize in building interactive, animated interfaces that engage users and tell compelling stories.
              
              My journey began with a fascination for the intersection of code and design, which led me to explore creative coding and animation libraries. I've since refined my skills to craft websites that not only function flawlessly but also provide memorable experiences through thoughtful animation and interaction design.
              
              When I'm not coding, you'll find me exploring new animation techniques, contributing to open-source projects, or sketching new interface ideas.
            </div>
            
            <div className="pt-6 scale-in-element" style={{ animationDelay: "600ms" }}>
              <Button className="btn btn-primary">Download Resume</Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {facts.map((fact, index) => (
              <div key={fact.title} className="scale-in-element" style={{ animationDelay: `${800 + index * 100}ms` }}>
                <FactCard 
                  title={fact.title}
                  content={fact.content}
                  index={index}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
