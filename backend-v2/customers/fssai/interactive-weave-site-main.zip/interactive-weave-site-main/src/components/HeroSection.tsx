
import { useEffect } from "react";
import { Github, Linkedin, Twitter } from "lucide-react";

const HeroSection = () => {
  return (
    <section
      id="hero"
      className="min-h-screen flex items-center relative overflow-hidden bg-grid pt-16"
    >
      <div id="hero-section" className="section relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="lg:w-1/2">
            <h1 
              id="hero-title" 
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6"
            >
              <span className="block">Hi, I'm </span>
              <span className="block text-gradient">John Doe</span>
              <span className="block">Interactive Developer</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              I create immersive web experiences with beautiful animations and interactive elements.
              Let's bring your vision to life with cutting-edge technology.
            </p>
            
            <div className="flex space-x-4">
              <a href="#projects" className="btn btn-primary">
                View My Work
              </a>
              <a href="#contact" className="btn btn-outline">
                Get In Touch
              </a>
            </div>
            
            <div className="flex items-center space-x-4 mt-10">
              <span className="text-muted-foreground">Follow me</span>
              <a 
                href="#" 
                className="social-icon text-muted-foreground hover:text-white transition-colors"
                aria-label="GitHub"
              >
                <Github size={20} />
              </a>
              <a 
                href="#" 
                className="social-icon text-muted-foreground hover:text-white transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="#" 
                className="social-icon text-muted-foreground hover:text-white transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div className="lg:w-1/2 flex justify-center">
            <div className="relative">
              <div 
                className="w-72 h-72 md:w-96 md:h-96 bg-gradient-to-br from-purple to-blue rounded-full opacity-50 blur-xl absolute"
                data-parallax="20"
              ></div>
              <div 
                className="w-72 h-72 md:w-96 md:h-96 bg-gradient-to-tr from-purple to-pink rounded-full opacity-50 blur-xl absolute -top-10 -right-10"
                data-parallax="15"
              ></div>
              <img 
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=800&ixid=MnwxfDB8MXxyYW5kb218MHx8cG9ydHJhaXR8fHx8fHwxNjE1MzMwODYw&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=800" 
                alt="Developer Portrait" 
                className="w-64 h-64 md:w-80 md:h-80 rounded-full object-cover border-4 border-white/10 relative z-10"
                data-parallax="5"
              />
              
              <div 
                className="absolute -top-5 -left-5 w-20 h-20 bg-purple rounded-full opacity-60 animate-float"
                data-parallax="25"
              ></div>
              <div 
                className="absolute -bottom-5 -right-5 w-16 h-16 bg-blue rounded-full opacity-60 animate-float"
                style={{ animationDelay: "1s" }}
                data-parallax="30"
              ></div>
              <div 
                className="absolute top-1/2 -right-10 w-12 h-12 bg-pink rounded-full opacity-60 animate-float"
                style={{ animationDelay: "2s" }}
                data-parallax="35"
              ></div>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-10 left-0 right-0 flex justify-center">
          <a 
            href="#about"
            className="text-white animate-bounce"
            aria-label="Scroll Down"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="24" 
              height="24" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <path d="M12 5v14"></path>
              <path d="m19 12-7 7-7-7"></path>
            </svg>
          </a>
        </div>
      </div>
      
      <div className="absolute top-0 left-0 right-0 bottom-0 bg-gradient-to-b from-background/0 to-background z-0"></div>
    </section>
  );
};

export default HeroSection;
