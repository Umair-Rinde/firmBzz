
import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import anime from "animejs";

interface Project {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string;
  tech: string[];
  demoUrl: string;
  sourceUrl: string;
  details: string;
  features: string[];
}

const ProjectCard = ({ project }: { project: Project }) => {
  const [expanded, setExpanded] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  
  const toggleExpanded = () => {
    const card = cardRef.current;
    if (!card) return;
    
    setExpanded(!expanded);
    
    if (!expanded) {
      anime({
        targets: card,
        height: "auto",
        maxHeight: 800,
        opacity: [1, 0, 1],
        duration: 800,
        easing: "easeInOutExpo",
        complete: () => {
          card.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      });
    } else {
      anime({
        targets: card,
        height: 400,
        maxHeight: 400,
        opacity: [1, 0.8, 1],
        duration: 600,
        easing: "easeInOutExpo",
      });
    }
  };
  
  return (
    <Card 
      ref={cardRef} 
      className={`overflow-hidden transition-all duration-300 ${expanded ? 'h-auto' : 'h-[400px]'}`}
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={project.image} 
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
        <div className="absolute top-2 right-2 bg-card/80 backdrop-blur-sm px-2 py-1 rounded text-xs">
          {project.category}
        </div>
      </div>
      
      <CardContent className="p-6">
        <h3 className="text-xl font-bold mb-2">{project.title}</h3>
        
        <div className="flex flex-wrap gap-2 mb-3">
          {project.tech.map((tech) => (
            <span 
              key={tech} 
              className="text-xs px-2 py-1 bg-muted rounded-full"
            >
              {tech}
            </span>
          ))}
        </div>
        
        <p className="text-muted-foreground mb-4">{project.description}</p>
        
        {expanded && (
          <div className="mt-6 animate-fade-in">
            <h4 className="font-semibold mb-2">Project Details</h4>
            <p className="mb-4">{project.details}</p>
            
            <h4 className="font-semibold mb-2">Key Features</h4>
            <ul className="list-disc pl-5 mb-6 space-y-1">
              {project.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
            
            <div className="flex gap-3 mt-4">
              <Button variant="default" asChild>
                <a href={project.demoUrl} target="_blank" rel="noreferrer">View Demo</a>
              </Button>
              <Button variant="outline" asChild>
                <a href={project.sourceUrl} target="_blank" rel="noreferrer">Source Code</a>
              </Button>
            </div>
          </div>
        )}
        
        <Button 
          variant="ghost" 
          className="mt-4"
          onClick={toggleExpanded}
          data-cursor="pointer"
        >
          {expanded ? "Show Less" : "Learn More"}
        </Button>
      </CardContent>
    </Card>
  );
};

const ProjectsSection = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [filteredProjects, setFilteredProjects] = useState<Project[]>([]);
  
  const projects: Project[] = [
    {
      id: "1",
      title: "Interactive Dashboard",
      description: "A real-time analytics dashboard with animated data visualizations.",
      image: "https://images.unsplash.com/photo-1487958449943-2429e8be8625",
      category: "Web App",
      tech: ["React", "anime.js", "D3.js", "Firebase"],
      demoUrl: "#",
      sourceUrl: "#",
      details: "This dashboard features real-time data visualization with smooth animations to display complex information in an intuitive way. The project uses anime.js for transitional animations and D3.js for data visualization.",
      features: [
        "Real-time data updates with animated transitions",
        "Interactive charts with hover states and tooltips",
        "Animated filtering and sorting of data",
        "Responsive design that works on all devices"
      ]
    },
    {
      id: "2",
      title: "E-Commerce Experience",
      description: "A modern e-commerce interface with interactive product exploration.",
      image: "https://images.unsplash.com/photo-1493397212122-2b85dda8106b",
      category: "E-Commerce",
      tech: ["Next.js", "anime.js", "Tailwind CSS", "Stripe"],
      demoUrl: "#",
      sourceUrl: "#",
      details: "This e-commerce platform focuses on providing a unique shopping experience with smooth animations and interactive product views. Products animate into view as users browse, and the checkout process features a seamless animated flow.",
      features: [
        "Animated product cards and hover effects",
        "Interactive 3D product views",
        "Smooth cart animations and transitions",
        "Animated checkout steps"
      ]
    },
    {
      id: "3",
      title: "Interactive Storytelling",
      description: "An immersive web experience that tells stories through animation.",
      image: "https://images.unsplash.com/photo-1527576539890-dfa815648363",
      category: "Interactive",
      tech: ["Three.js", "anime.js", "WebGL", "GSAP"],
      demoUrl: "#",
      sourceUrl: "#",
      details: "This interactive story experience uses a combination of animation libraries to create an immersive narrative that responds to user actions. Scroll-based animations reveal content as the user progresses through the story.",
      features: [
        "Parallax scrolling effects",
        "Character animations that respond to user input",
        "Timeline-based story progression",
        "Audio integration synchronized with animations"
      ]
    },
    {
      id: "4",
      title: "Portfolio Template",
      description: "A customizable portfolio template with smooth animations and transitions.",
      image: "https://images.unsplash.com/photo-1501854140801-50d01698950b",
      category: "Template",
      tech: ["React", "anime.js", "Framer Motion", "Tailwind CSS"],
      demoUrl: "#",
      sourceUrl: "#",
      details: "This portfolio template is designed for creative professionals who want to showcase their work with style. It features a range of animations and interactive elements that make browsing projects engaging and memorable.",
      features: [
        "Animated page transitions",
        "Interactive project gallery",
        "Animated skill bars and progress indicators",
        "Contact form with validation animations"
      ]
    }
  ];
  
  useEffect(() => {
    if (activeTab === "all") {
      setFilteredProjects(projects);
    } else {
      setFilteredProjects(projects.filter(project => project.category.toLowerCase() === activeTab));
    }
    
    // Animate cards when tab changes
    anime({
      targets: ".project-card",
      opacity: [0, 1],
      translateY: [20, 0],
      delay: anime.stagger(100),
      easing: "easeOutExpo",
      duration: 600
    });
  }, [activeTab]);

  return (
    <section id="projects" className="py-20 bg-muted/20">
      <div className="section">
        <h2 className="section-title slide-in-right-element">My Projects</h2>
        <p className="section-subtitle slide-in-right-element" style={{ animationDelay: "100ms" }}>
          Explore my recent work and interactive experiences.
        </p>
        
        <Tabs 
          defaultValue="all" 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="mb-10"
        >
          <TabsList className="mx-auto flex justify-center">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="web app">Web App</TabsTrigger>
            <TabsTrigger value="e-commerce">E-Commerce</TabsTrigger>
            <TabsTrigger value="interactive">Interactive</TabsTrigger>
            <TabsTrigger value="template">Templates</TabsTrigger>
          </TabsList>
          
          <TabsContent value={activeTab} className="mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {filteredProjects.map((project) => (
                <div key={project.id} className="project-card opacity-0">
                  <ProjectCard project={project} />
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="flex justify-center mt-12 fade-in-element" style={{ animationDelay: "400ms" }}>
          <Button className="btn btn-primary">View All Projects</Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
