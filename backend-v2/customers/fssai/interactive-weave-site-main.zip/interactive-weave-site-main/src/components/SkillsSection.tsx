
import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Html, Css, Javascript, React } from "lucide-react";
import anime from "animejs";

interface TechIconProps {
  icon: React.ReactNode;
  name: string;
  level: number;
  color: string;
}

const TechIcon = ({ icon, name, level, color }: TechIconProps) => {
  const iconRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const el = iconRef.current;
    if (!el) return;
    
    el.addEventListener("mouseenter", () => {
      anime({
        targets: el,
        scale: 1.1,
        rotate: "10deg",
        boxShadow: `0 10px 30px -10px ${color}`,
        duration: 400,
        easing: "easeOutCubic",
      });
    });
    
    el.addEventListener("mouseleave", () => {
      anime({
        targets: el,
        scale: 1,
        rotate: "0deg",
        boxShadow: "0 0 0 rgba(0,0,0,0)",
        duration: 400,
        easing: "easeOutCubic",
      });
    });
  }, [color]);
  
  return (
    <div 
      ref={iconRef}
      className="tech-icon bg-card flex flex-col items-center justify-center p-6 rounded-lg card-hover"
      data-cursor="pointer"
    >
      <div 
        className="w-16 h-16 flex items-center justify-center rounded-full mb-4"
        style={{ backgroundColor: `${color}20`, color: color }}
      >
        {icon}
      </div>
      <h3 className="font-bold mb-2">{name}</h3>
      <div className="w-full bg-muted/30 rounded-full h-2 mb-1">
        <div 
          className="h-2 rounded-full" 
          style={{ width: `${level}%`, backgroundColor: color }}
        ></div>
      </div>
      <p className="text-sm text-muted-foreground">{level}% Proficiency</p>
    </div>
  );
};

const SkillsSection = () => {
  const [filter, setFilter] = useState<string>("all");
  const skillsContainerRef = useRef<HTMLDivElement>(null);

  const filterSkills = (category: string) => {
    setFilter(category);
    
    if (!skillsContainerRef.current) return;
    
    const items = skillsContainerRef.current.querySelectorAll(".tech-icon");
    
    anime({
      targets: items,
      scale: 0,
      opacity: 0,
      duration: 400,
      easing: "easeOutQuad",
      delay: anime.stagger(50),
      complete: () => {
        setTimeout(() => {
          anime({
            targets: skillsContainerRef.current?.querySelectorAll(
              category === "all" ? ".tech-icon" : `.tech-icon[data-category="${category}"]`
            ),
            scale: [0, 1],
            opacity: [0, 1],
            duration: 500,
            easing: "easeOutElastic(1, .6)",
            delay: anime.stagger(100),
          });
        }, 100);
      },
    });
  };

  const techIcons = [
    { 
      icon: <Html size={32} />, 
      name: "HTML5", 
      level: 95, 
      color: "#E34F26", 
      category: "frontend" 
    },
    { 
      icon: <Css size={32} />, 
      name: "CSS3", 
      level: 90, 
      color: "#1572B6", 
      category: "frontend" 
    },
    { 
      icon: <Javascript size={32} />, 
      name: "JavaScript", 
      level: 92, 
      color: "#F7DF1E", 
      category: "frontend" 
    },
    { 
      icon: <React size={32} />, 
      name: "React", 
      level: 88, 
      color: "#61DAFB", 
      category: "frontend" 
    },
    { 
      icon: <svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
        <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-.471 5.594l7.5 4.336c.175.101.281.291.281.494v3.42c-.006.191-.104.363-.26.461l-7.5 4.336c-.103.059-.219.09-.335.09s-.232-.031-.335-.09l-7.5-4.336c-.157-.099-.255-.271-.26-.462v-3.41c0-.203.107-.393.281-.494l7.5-4.336c.205-.119.457-.119.662 0l-.033-.02z" /></svg>, 
      name: "Next.js", 
      level: 85, 
      color: "#000000", 
      category: "frontend" 
    },
    { 
      icon: <svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
        <path d="M18.7 3.04c-.47 0-.94.19-1.28.53l-1.7 1.7 3.75 3.75 1.7-1.7c.7-.7.7-1.84 0-2.55l-1.2-1.19c-.35-.35-.83-.54-1.27-.54zm-3.48 2.73l-11.22 11.22v3.75h3.75l11.22-11.22-3.75-3.75z" /></svg>, 
      name: "Figma", 
      level: 78, 
      color: "#F24E1E", 
      category: "design" 
    },
    { 
      icon: <svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
        <path d="M24 18.588a1.529 1.529 0 01-1.543 1.5c-.793 0-1.465-.56-1.52-1.327l-.034-.262c-.91.062-1.887.098-2.92.098-4.648 0-8.413-.586-10.074-1.493a1.406 1.406 0 01-.273.28c-.392.32-.876.506-1.399.508-.166 0-.334-.02-.5-.062a1.605 1.605 0 01-1.238-1.306 1.6 1.6 0 01.748-1.637A1.596 1.596 0 016.7 11.66c.036 0 .07.005.106.005a1.4 1.4 0 01.532.103c2.46-1.128 7.52-1.827 12.64-1.827.85 0 1.675.028 2.476.07l-.003-.265c0-.78.567-1.415 1.329-1.513a1.51 1.51 0 011.65 1.118 1.496 1.496 0 01.22.708zM7.424 18.606c.292.3.711.474 1.156.474a1.6 1.6 0 001.595-1.602 1.585 1.585 0 00-1.595-1.573 1.59 1.59 0 00-1.156 2.701zm10.502-8.058c-4.962 0-9.793.722-12.173 1.88-.078-.08-.164-.15-.256-.214a1.403 1.403 0 00-.815-.25c-.036 0-.07.004-.106.004-.3.015-.582.17-.78.445a1.405 1.405 0 00-.116 1.457c.134.267.333.48.57.626-.015.293-.025.59-.025.89 0 2.25.83 4.424 2.285 6.03C8.473 23.142 12.982 24 17.968 24c4.257 0 8.322-.677 10.602-1.827.884-.446 1.428-1.11 1.428-1.852v-6.618c0-.742-.544-1.408-1.43-1.854-1.104-.553-2.708-.98-4.539-1.25-.654-.096-1.323-.182-2.003-.248a1.484 1.484 0 00-2.78-.416 1.473 1.473 0 00-.583 1.08c-.834-.053-1.67-.08-2.505-.08a45.3 45.3 0 00-3.229.113zm-5.503.598c.292.3.711.474 1.156.474a1.6 1.6 0 001.595-1.603A1.585 1.585 0 0013.58 8.444a1.59 1.59 0 00-1.157 2.702z" /></svg>, 
      name: "Three.js", 
      level: 72, 
      color: "#049EF4", 
      category: "3d" 
    },
    { 
      icon: <svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
        <path d="M12 10.11c1.03 0 1.87.84 1.87 1.89 0 1-.84 1.85-1.87 1.85-1.03 0-1.87-.85-1.87-1.85 0-1.05.84-1.89 1.87-1.89M7.37 20c.63.38 2.01-.2 3.6-1.7-.52-.59-1.03-1.23-1.51-1.9a22.7 22.7 0 01-2.4-.36c-.51 2.14-.32 3.61.31 3.96m.71-5.74l-.29-.51c-.11.29-.22.58-.29.86.27.06.57.11.88.16l-.3-.51m6.54-.76l.81-1.5-.81-1.5c-.3-.53-.62-1-.91-1.47C13.17 9 12.6 9 12 9c-.6 0-1.17 0-1.71.03-.29.47-.61.94-.91 1.47L8.57 12l.81 1.5c.3.53.62 1 .91 1.47.54.03 1.11.03 1.71.03.6 0 1.17 0 1.71-.03.29-.47.61-.94.91-1.47M12 6.78c-.19.22-.39.45-.59.72h1.18c-.2-.27-.4-.5-.59-.72m0 10.44c.19-.22.39-.45.59-.72h-1.18c.2.27.4.5.59.72M16.62 4c-.62-.38-2 .2-3.59 1.7.52.59 1.03 1.23 1.51 1.9.82.08 1.63.2 2.4.36.51-2.14.32-3.61-.32-3.96m-.7 5.74l.29.51c.11-.29.22-.58.29-.86-.27-.06-.57-.11-.88-.16l.3.51m1.45-7.05c1.47.84 1.63 3.05 1.01 5.63 2.54.75 4.37 1.99 4.37 3.68 0 1.69-1.83 2.93-4.37 3.68.62 2.58.46 4.79-1.01 5.63-1.46.84-3.45-.12-5.37-1.95-1.92 1.83-3.91 2.79-5.38 1.95-1.46-.84-1.62-3.05-1-5.63-2.54-.75-4.37-1.99-4.37-3.68 0-1.69 1.83-2.93 4.37-3.68-.62-2.58-.46-4.79 1-5.63 1.47-.84 3.46.12 5.38 1.95 1.92-1.83 3.91-2.79 5.37-1.95M17.08 12c.34.75.64 1.5.89 2.26 2.1-.63 3.28-1.53 3.28-2.26 0-.73-1.18-1.63-3.28-2.26-.25.76-.55 1.51-.89 2.26M6.92 12c-.34-.75-.64-1.5-.89-2.26-2.1.63-3.28 1.53-3.28 2.26 0 .73 1.18 1.63 3.28 2.26.25-.76.55-1.51.89-2.26m9 2.26l-.3.51c.31-.05.61-.1.88-.16-.07-.28-.18-.57-.29-.86l-.29.51m-2.89 4.04c1.59 1.5 2.97 2.08 3.59 1.7.64-.35.83-1.82.32-3.96-.77.16-1.58.28-2.4.36-.48.67-.99 1.31-1.51 1.9M8.08 9.74l.3-.51c-.31.05-.61.1-.88.16.07.28.18.57.29.86l.29-.51m2.89-4.04C9.38 4.2 8 3.62 7.37 4c-.63.36-.82 1.83-.31 3.96a22.7 22.7 0 012.4-.36c.48-.67.99-1.31 1.51-1.9z" /></svg>, 
      name: "React Native", 
      level: 80, 
      color: "#61DAFB", 
      category: "mobile" 
    }
  ];

  useEffect(() => {
    // Initial animation when component mounts
    setTimeout(() => {
      anime({
        targets: ".tech-icon",
        scale: [0, 1],
        opacity: [0, 1],
        delay: anime.stagger(100),
        duration: 800,
        easing: "easeOutElastic(1, .6)",
      });
    }, 300);
  }, []);

  return (
    <section id="skills" className="py-20">
      <div className="section">
        <h2 className="section-title fade-in-element">Technical Skills</h2>
        <p className="section-subtitle fade-in-element" style={{ animationDelay: "100ms" }}>
          Technologies and tools I work with to bring ideas to life.
        </p>
        
        <div className="flex flex-wrap justify-center gap-4 mb-10 fade-in-element" style={{ animationDelay: "200ms" }}>
          <Button 
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => filterSkills("all")}
            className="min-w-[100px]"
          >
            All
          </Button>
          <Button 
            variant={filter === "frontend" ? "default" : "outline"}
            onClick={() => filterSkills("frontend")}
            className="min-w-[100px]"
          >
            Frontend
          </Button>
          <Button 
            variant={filter === "design" ? "default" : "outline"}
            onClick={() => filterSkills("design")}
            className="min-w-[100px]"
          >
            Design
          </Button>
          <Button 
            variant={filter === "3d" ? "default" : "outline"}
            onClick={() => filterSkills("3d")}
            className="min-w-[100px]"
          >
            3D
          </Button>
          <Button 
            variant={filter === "mobile" ? "default" : "outline"}
            onClick={() => filterSkills("mobile")}
            className="min-w-[100px]"
          >
            Mobile
          </Button>
        </div>
        
        <div 
          ref={skillsContainerRef}
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
        >
          {techIcons.map((tech, index) => (
            <div 
              key={tech.name} 
              className="tech-icon opacity-0 scale-0" 
              data-category={tech.category}
              style={{ transformOrigin: "center" }}
            >
              <TechIcon 
                icon={tech.icon}
                name={tech.name}
                level={tech.level}
                color={tech.color}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
